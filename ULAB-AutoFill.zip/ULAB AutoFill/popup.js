
document.getElementById('toggle').onclick = async()=>{
  const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
  await chrome.scripting.executeScript({target:{tabId:tab.id}, files:['content.js']});
  setTimeout(()=>chrome.tabs.sendMessage(tab.id, {action:'TOGGLE_UA'}), 200);
};
