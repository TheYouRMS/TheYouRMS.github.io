
(function(){
  function createPanel(){
    var existing = document.getElementById('ulab-autofill-root');
    if(existing){ 
      if(existing.style.display==='none'){
        existing.style.display='block';
        var mini=document.getElementById('ulab-minimized');
        if(mini) mini.style.display='none';
      } else {
        existing.style.display='none';
        var mini2=document.getElementById('ulab-minimized');
        if(mini2) mini2.style.display='block';
      }
      return;
    }
    var miniExisting = document.getElementById('ulab-minimized');
    if(miniExisting){ miniExisting.remove(); }

    var f = document.querySelector("#TEForm,#CEForm");
    if(!f){ return; }
    var isTeacher = f.id=="TEForm";

    var rootEl = document.createElement('div');
    rootEl.id = 'ulab-autofill-root';
    // 75% of previous 360px = 270px, resizable
    rootEl.style.cssText = 'position:fixed;top:20px;right:20px;width:270px;min-width:240px;max-width:90vw;min-height:200px;max-height:85vh;z-index:9999999;font-family:Arial,sans-serif;background:#111;color:#fff;border:1px solid #555;border-radius:14px;overflow:hidden;box-shadow:0 10px 30px rgba(0,0,0,0.5);display:flex;flex-direction:column;resize:both;';

    var header = document.createElement('div');
    header.style.cssText = 'background:#181818;color:#fff;padding:10px 14px;display:flex;justify-content:space-between;align-items:center;font-weight:bold;font-size:13px;border-bottom:1px solid #333;cursor:move;user-select:none;flex-shrink:0;';
    var title = document.createElement('span');
    title.textContent = 'ULAB '+(isTeacher?'Teacher':'Course')+' Evaluation';
    title.style.cssText = 'font-size:13px;';

    var minBtn = document.createElement('button');
    minBtn.textContent = '−';
    minBtn.title = 'Minimize';
    minBtn.style.cssText = 'background:#222;border:1px solid #444;color:#aaa;width:26px;height:26px;border-radius:6px;cursor:pointer;font-size:16px;line-height:1;display:flex;align-items:center;justify-content:center;';

    header.appendChild(title);
    header.appendChild(minBtn);

    var body = document.createElement('div');
    body.style.cssText = 'padding:14px;overflow-y:auto;flex:1;';

    function el(tag){return document.createElement(tag)}
    function createSelect(options){
      var sel = el('select');
      sel.style.cssText = 'width:100%;padding:9px;margin:4px 0 8px;background:#222;color:#fff;border:1px solid #555;border-radius:7px;font-size:12px;outline:none;';
      var def = el('option'); def.textContent='Select...'; def.value=''; def.disabled=true; def.selected=true; sel.appendChild(def);
      for(var i=0;i<options.length;i++){ var o=el('option'); o.value=options[i][0]; o.textContent=options[i][1]; sel.appendChild(o); }
      return sel;
    }
    function label(text){
      var l = el('div'); l.textContent=text; l.style.cssText='font-size:11px;color:#999;margin-top:10px;margin-bottom:4px;text-transform:uppercase;letter-spacing:0.3px;'; body.appendChild(l); return l;
    }

    label('Rating for all questions');
    var r = createSelect([['5','5 — Strongly Agree'],['4','4 — Agree'],['3','3 — Neutral'],['2','2 — Disagree'],['1','1 — Strongly Disagree']]);
    body.appendChild(r);

    label('Comment');
    var m = createSelect([['na','N/A'],['writer','Comment Writer']]);
    body.appendChild(m);

    var ex = el('div');
    ex.style.cssText = 'display:none;padding:10px;background:#181818;border-radius:8px;margin-top:8px;border:1px solid #333;';
    body.appendChild(ex);

    var ta = el('textarea');
    ta.placeholder='Generated comment';
    ta.style.cssText='width:100%;height:70px;box-sizing:border-box;margin-top:8px;background:#222;color:#fff;border:1px solid #555;border-radius:7px;padding:8px;font-size:12px;resize:vertical;outline:none;';
    body.appendChild(ta);

    var a,b,c;
    function fld(name){
      var sel = el('select');
      sel.style.cssText='width:100%;padding:8px;background:#222;color:#fff;border:1px solid #555;border-radius:7px;margin-top:4px;font-size:12px;outline:none;';
      var def = el('option'); def.textContent='Select...'; def.value=''; def.disabled=true; def.selected=true; sel.appendChild(def);
      var good = el('option'); good.value='g'; good.textContent='Good'; sel.appendChild(good);
      var imp = el('option'); imp.value='i'; imp.textContent='Needs Improvement'; sel.appendChild(imp);
      var lab = el('div'); lab.textContent=name; lab.style.cssText='font-size:11px;color:#999;margin-top:8px;';
      ex.appendChild(lab); ex.appendChild(sel);
      return sel;
    }
    function upd(){
      if(m.value!='writer'){ta.value='';return}
      if(!a||!b||!c||!a.value||!b.value||!c.value){ta.value='';return}
      if(isTeacher)ta.value=(a.value=='g'?'The teaching was clear and effective.':'The teaching could be improved further.')+' '+(b.value=='g'?'Communication with students was clear and helpful.':'Communication with students could be improved further.')+' '+(c.value=='g'?'The teacher maintained a professional approach.':'Professionalism could be improved further.');
      else ta.value=(a.value=='g'?'The curriculum was appropriate.':'The curriculum could be improved further.')+' '+(b.value=='g'?'The learning materials were useful.':'The learning materials could be improved further.')+' '+(c.value=='g'?'The course was well organized.':'The course organization could be improved further.');
    }
    m.onchange=function(){
      ex.innerHTML=''; ta.value='';
      if(m.value=='writer'){
        a=fld(isTeacher?'Teaching':'Curriculum');
        b=fld(isTeacher?'Communication':'Learning Materials');
        c=fld(isTeacher?'Professionalism':'Course Organization');
        a.onchange=upd; b.onchange=upd; c.onchange=upd;
        ex.style.display='block';
      } else {
        ex.style.display='none';
      }
    };

    var go = el('button');
    go.textContent='Autofill All';
    go.style.cssText='width:100%;padding:11px;margin-top:12px;background:#2563eb;color:#fff;border:0;border-radius:8px;font-weight:bold;cursor:pointer;font-size:13px;';
    body.appendChild(go);

    var st = el('div');
    st.style.cssText='font-size:11px;color:#7a9a7a;margin-top:8px;min-height:14px;';
    body.appendChild(st);

    go.onclick=function(){
      if(!r.value||!m.value){st.textContent='Select rating and comment option first.';return}
      if(m.value=='writer'&&(!a.value||!b.value||!c.value)){st.textContent='Select all comment options first.';return}
      upd();
      var map={}, q=f.querySelectorAll('input[type="radio"][name^="rate"]'), n=0;
      for(var i=0;i<q.length;i++) map[q[i].name]=1;
      for(var j in map){
        var x=f.querySelector('input[name="'+j+'"][value="'+r.value+'"]');
        if(x){x.checked=true;x.dispatchEvent(new Event("change",{bubbles:true}));n++}
      }
      var ta2=f.querySelector('textarea[name="txtTEComments"]');
      if(ta2){ta2.value=m.value=="na"?"N/A":ta.value;ta2.dispatchEvent(new Event("input",{bubbles:true}));ta2.dispatchEvent(new Event("change",{bubbles:true}))}
      st.textContent='Filled '+n+' questions. Review before submitting.';
      var orig=go.textContent; go.textContent='Filled '+n+'!'; go.style.background='#16a34a';
      setTimeout(function(){go.textContent=orig;go.style.background='#2563eb';},2000);
    };

    rootEl.appendChild(header);
    rootEl.appendChild(body);
    document.body.appendChild(rootEl);

    // Minimized pill
    var mini = document.createElement('div');
    mini.id = 'ulab-minimized';
    mini.textContent = 'ULAB Fill';
    mini.style.cssText = 'position:fixed;top:20px;right:20px;z-index:9999999;background:#111;color:#fff;border:1px solid #555;padding:8px 14px;border-radius:20px;cursor:pointer;font-family:Arial;font-size:12px;font-weight:bold;box-shadow:0 5px 15px rgba(0,0,0,0.3);display:none;';
    document.body.appendChild(mini);

    function minimize(){
      rootEl.style.display='none';
      mini.style.display='block';
    }
    function restore(){
      rootEl.style.display='flex';
      mini.style.display='none';
    }

    minBtn.onclick = minimize;
    mini.onclick = restore;

    // Make draggable via header
    var isDragging=false, startX, startY, initLeft, initTop;
    header.addEventListener('mousedown', function(e){
      isDragging=true;
      startX=e.clientX; startY=e.clientY;
      var rect=rootEl.getBoundingClientRect();
      initLeft=rect.left; initTop=rect.top;
      rootEl.style.right='auto';
      rootEl.style.bottom='auto';
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
      e.preventDefault();
    });
    function onMove(e){
      if(!isDragging) return;
      rootEl.style.left = (initLeft + e.clientX - startX) + 'px';
      rootEl.style.top = (initTop + e.clientY - startY) + 'px';
    }
    function onUp(){ isDragging=false; document.removeEventListener('mousemove', onMove); document.removeEventListener('mouseup', onUp); }
  }

  if(document.querySelector("#TEForm,#CEForm")){
    setTimeout(createPanel, 600);
  }

  if(typeof chrome !== 'undefined' && chrome.runtime){
    chrome.runtime.onMessage.addListener(function(msg){
      if(msg.action==="TOGGLE_UA"){ createPanel(); }
    });
  }
})();
